const express = require("express");
const app = express();

const PORT = process.env.PORT || 3000;

// Ruta para devolver un número aleatorio
app.get("/random", (req, res) => {
  try {
    const randomNumber = Math.floor(Math.random() * 100) + 1;
    res.json({ number: randomNumber, message: "Random number generated" });
  } catch (error) {
    res.status(500).json({ error: "Error al generar el número aleatorio" });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});
// AWS_ACCESS_KEY_ID = AKIAWQUOZU76EXHZS75H;
// AWS_SECRET_ACCESS_KEY = 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;
// AWS_REGION = us - east - 2;
us - east - 2;
